﻿#======================================================================================================================================================================#
#==================================================================User Input Section Start ===========================================================================#
# Target application name showing in Registry

$targetApp = "VLC media player"

#===================================================================User Input Section End ============================================================================#
#======================================================================================================================================================================#


# Registry paths with bitness
$registrySources = @(
    @{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"; Bit = "64Bit" },
    @{ Path = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"; Bit = "32Bit" }
)

$found = $false

foreach ($source in $registrySources) {
    $subkeys = Get-ChildItem -Path $source.Path -ErrorAction SilentlyContinue

    foreach ($subkey in $subkeys) {
        $app = Get-ItemProperty -Path $subkey.PSPath -ErrorAction SilentlyContinue

        if ($app.DisplayName -eq "$targetApp") {
            $found = $true

            # Clean registry path
            $cleanPath = $subkey.PSPath -replace '^Microsoft\.PowerShell\.Core\\Registry::', ''

            # Determine Application Type based on registry key name
            $regKeyName = Split-Path $cleanPath -Leaf
            if ($regKeyName -match '^\{[0-9A-Fa-f\-]{36}\}$') {
                $appType = "MSI"
            } else {
                $appType = "EXE"
            }

            # Handle Silent Switch
            if ($appType -eq "MSI") {
                # Build MSI standard silent uninstall command
                $safeLogName = ($app.DisplayName -replace '[\\/:*?"<>|]', '_')
                $silentSwitch = "/qn /norestart /l*v `"C:\Windows\Logs\$safeLogName.log`""
            } else {
                # Try to extract from QuietUninstallString
                $silentSwitch = ""
                if ($app.QuietUninstallString) {
                    if ($app.QuietUninstallString -match '^(\"[^\"]+\"|\S+)\s+(.*)$') {
                        $silentSwitch = $matches[2].Trim()
                    }
                }
                if ([string]::IsNullOrWhiteSpace($silentSwitch)) {
                    $silentSwitch = "Silent switch not found – check vendor documentation"
                }
            }

            # Prepare output content
            $output = @()
            $output += "DisplayName         : $($app.DisplayName)"
            $output += "DisplayVersion      : $($app.DisplayVersion)"
            $output += "HelpLink            : $($app.HelpLink)"
            $output += "Publisher           : $($app.Publisher)"
            $output += "Readme              : $($app.Readme)"
            $output += "Size                : $($app.Size)"
            $output += "EstimatedSize       : $($app.EstimatedSize)"
            $output += "SilentSwitch        : $silentSwitch"
            $output += "UninstallString     : $($app.UninstallString)"
            $output += "QuietUninstallString: $($app.QuietUninstallString)"
            $output += "URLInfoAbout        : $($app.URLInfoAbout)"
            $output += "URLUpdateInfo       : $($app.URLUpdateInfo)"
            $output += "Language            : $($app.Language)"
            $output += "InstallLocation     : $($app.InstallLocation)"
            $output += "ApplicationType     : $appType"
            $output += "Registry Bitness    : $($source.Bit)"
            $output += "Registry Location   : $cleanPath"

            # Create output file name (sanitize invalid file characters)
            $safeDisplayName = ($app.DisplayName -replace '[\\/:*?"<>|]', '_')
            $safeVersion = ($app.DisplayVersion -replace '[\\/:*?"<>|]', '_')
            $fileName = "$safeDisplayName" + "_$safeVersion" + "_$($source.Bit).txt"

            # Output path (Desktop)
            $filePath = Join-Path -Path $env:USERPROFILE\Desktop -ChildPath $fileName

            # Save to file
            $output | Out-File -FilePath $filePath -Encoding UTF8

            Write-Host "$targetApp Application info exported to:" -ForegroundColor Green
            Write-Host $filePath -ForegroundColor Yellow

            # Open in Notepad
            Start-Process notepad.exe $filePath
            break
        }
    }

    if ($found) { break }
}

if (-not $found) {
    Write-Host "Application '$targetApp' not found in registry." -ForegroundColor Red
}
